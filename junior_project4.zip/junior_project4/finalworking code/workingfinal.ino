// ===== Blynk Template Info (must be FIRST) =====
#define BLYNK_TEMPLATE_ID   "TMPL3h9WdU1ZV"
#define BLYNK_TEMPLATE_NAME "esp32 safety device"
#define BLYNK_AUTH_TOKEN    "LM8XS1_g-hblZwL0WzwxqfsmD5ZVtHhd"

#define BLYNK_PRINT Serial

#include <HardwareSerial.h>
#include <WiFi.h>
#include <BlynkSimpleEsp32.h>
#include <DHT.h>
#include <TinyGPSPlus.h>

// -------- WiFi Credentials --------
const char WIFI_SSID[] = "afeez";
const char WIFI_PASS[] = "afeez123";

BlynkTimer timer;

// ===== Modem Serial (SIM800) =====
HardwareSerial sim800(1); // UART1

// ===== GPS Serial (NEO-6M) =====
HardwareSerial gpsSerial(2); // UART2

// ===== Modem pins =====
#define MODEM_TX       27
#define MODEM_RX       26
#define MODEM_PWRKEY   4
#define MODEM_POWER_ON 23
#define MODEM_RESET    5

// ===== Pulse sensor =====
#define PULSE_PIN 35

// ===== DHT11 sensor =====
#define DHTPIN 14
#define DHTTYPE DHT11
DHT dht(DHTPIN, DHTTYPE);

// ===== GPS pins (NEO-6M) =====
// NEO-6M TX -> ESP32 RX, NEO-6M RX -> ESP32 TX
#define GPS_RX_PIN 16   // ESP32 RX2 (receives from GPS TX)
#define GPS_TX_PIN 17   // ESP32 TX2 (goes to GPS RX)

TinyGPSPlus gps;

// ===== Buzzer =====
#define BUZZER_PIN 12   // Active HIGH buzzer connected to GPIO 25
int buzzerState = LOW;  // track current buzzer state

// ===== Fallback values if sensors fail =====
const float  DEFAULT_BPM  = 90.0;        // used if pulse not detected
const float  DEFAULT_TEMP = 30.0;        // used if DHT read fails (°C)
const double DEFAULT_LAT  = 13.044973;   // used if GPS fix fails
const double DEFAULT_LNG  = 74.978113;   // used if GPS fix fails

// ===== Alert thresholds (only for real readings) =====
const float BPM_HIGH_LIMIT   = 120.0;  // HR too high
const float BPM_LOW_LIMIT    = 40.0;   // HR too low
const float TEMP_HIGH_LIMIT  = 40.0;   // high fever
const float TEMP_LOW_LIMIT   = 20.0;   // low temperature

bool   alertSmsSent = false;
unsigned long lastAlertTime = 0;
const unsigned long ALERT_COOLDOWN_MS = 300000; // 5 minutes

// Filter parameters for pulse
float filtered = 0;
float avgLevel = 0;
bool firstSample = true;

const float alpha = 0.2;   // low-pass filter for signal
const float beta  = 0.01;  // slow average for baseline

// Beat detection
int thresholdOffset = 30;  // adjust if needed
bool aboveThreshold = false;
unsigned long lastBeatTime = 0;

// Result variables
float lastBPM = 0.0;
bool  bpmValid = false;

// DHT results
float lastTemperature = NAN;
float lastHumidity    = NAN;
bool  dhtValid        = false;

// GPS results
double lastLat = 0.0;
double lastLng = 0.0;
bool   gpsValid = false;

// SMS flag (for initial health report SMS)
bool smsSent = false;

const char* PHONE_NUMBER = "+918105215353";  // destination number

// ======== Function Declarations ========
void measureAndSend(bool sendSMS);
void timerCallback();

// ===== Blynk handler for buzzer (V4) =====
BLYNK_WRITE(V4) {
  int value = param.asInt();        // 0 or 1 from app
  buzzerState = value ? HIGH : LOW;
  digitalWrite(BUZZER_PIN, buzzerState);
  Serial.print("Buzzer set to: ");
  Serial.println(buzzerState == HIGH ? "ON" : "OFF");
}

// ===== Modem helpers =====
void powerOnModem() {
  pinMode(MODEM_PWRKEY, OUTPUT);
  pinMode(MODEM_POWER_ON, OUTPUT);
  pinMode(MODEM_RESET, OUTPUT);

  digitalWrite(MODEM_POWER_ON, HIGH);
  digitalWrite(MODEM_RESET, HIGH);

  Serial.println("Powering on modem...");
  digitalWrite(MODEM_PWRKEY, LOW);
  delay(1000);
  digitalWrite(MODEM_PWRKEY, HIGH);
  delay(5000);
}

void sendAT(const char* cmd, uint16_t waitMs = 1000) {
  sim800.print(cmd);
  sim800.print("\r");
  Serial.print(">> ");
  Serial.println(cmd);

  unsigned long start = millis();
  while (millis() - start < waitMs) {
    while (sim800.available()) {
      Serial.write(sim800.read());
    }
  }
  Serial.println();
}

bool waitForNetwork(uint32_t timeoutMs) {
  unsigned long start = millis();
  while (millis() - start < timeoutMs) {
    sim800.print("AT+CREG?\r");
    delay(500);

    String resp = "";
    unsigned long t = millis();
    while (millis() - t < 500) {
      if (sim800.available()) {
        resp += (char)sim800.read();
      }
    }
    Serial.print(resp);

    if (resp.indexOf(",1") != -1 || resp.indexOf(",5") != -1) {
      Serial.println("Network registered OK");
      return true;
    }
    delay(1000);
  }
  return false;
}

// Renamed to avoid name conflicts with libraries
void sendSMSviaSIM800(const char* number, const char* text) {
  Serial.println("Preparing to send SMS...");

  sendAT("AT+CMGF=1");  // text mode

  // Set recipient
  sim800.print("AT+CMGS=\"");
  sim800.print(number);
  sim800.print("\"\r");
  Serial.print(">> AT+CMGS=\"");
  Serial.print(number);
  Serial.println("\"");
  delay(1000); // wait for '>'

  // Message body
  sim800.print(text);
  Serial.print(">> ");
  Serial.println(text);
  delay(1000);

  // Ctrl+Z to send
  sim800.write(26);
  Serial.println("Sent Ctrl+Z, waiting for modem to send SMS...");

  // Read response for a while
  unsigned long start = millis();
  while (millis() - start < 15000) {
    while (sim800.available()) {
      Serial.write(sim800.read());
    }
  }
}

// ===== Pulse measurement (10 seconds) =====
void measureHeartRate10sec() {
  const unsigned long measureTime = 10000; // 10 seconds
  unsigned long startTime = millis();
  int beatCount = 0;

  Serial.println("Measuring heart rate for 10 seconds...");
  delay(100);

  // Initialize filter with first read
  int raw = analogRead(PULSE_PIN);
  filtered = raw;
  avgLevel = raw;
  firstSample = false;
  aboveThreshold = false;
  lastBeatTime = 0;

  while (millis() - startTime < measureTime) {
    unsigned long now = millis();
    raw = analogRead(PULSE_PIN);

    // Low-pass filter
    filtered = alpha * raw + (1.0 - alpha) * filtered;

    // Slow moving average for baseline
    avgLevel = avgLevel + beta * (filtered - avgLevel);

    float threshold = avgLevel + thresholdOffset;

    bool nowAbove = (filtered > threshold);

    // Rising edge detection
    if (!aboveThreshold && nowAbove) {
      unsigned long interval = now - lastBeatTime;

      // Ignore first beat interval or impossible values
      if (lastBeatTime == 0 || (interval > 300 && interval < 2000)) {
        beatCount++;
        lastBeatTime = now;

        Serial.print("Beat #");
        Serial.print(beatCount);
        Serial.print(" at ");
        Serial.print(now - startTime);
        Serial.println(" ms");
      }
    }

    aboveThreshold = nowAbove;

    Blynk.run(); // keep Blynk alive
    delay(10);   // ~100 samples per second
  }

  Serial.println("Heart rate measurement finished.");

  if (beatCount == 0) {
    Serial.println("Could not detect beats, using fallback heart rate value.");
    // No pulse detected → use fallback heart rate
    lastBPM = DEFAULT_BPM;
    bpmValid = false;
  } else {
    // 10-second window → BPM = beats * 6
    lastBPM = beatCount * 6.0;
    bpmValid = true;

    Serial.print("\n====================================\n");
    Serial.print("Measured heart rate: ");
    Serial.print(lastBPM, 1);
    Serial.println(" bpm");
    Serial.println("====================================\n");
  }
}

// ===== DHT11 measurement =====
void readDHTSensor() {
  Serial.println("Reading DHT11...");
  float t = dht.readTemperature(); // Celsius
  float h = dht.readHumidity();

  if (isnan(t) || isnan(h)) {
    Serial.println("Failed to read from DHT11, using fallback temperature.");
    // DHT11 read failed → use fallback temperature, humidity unknown
    lastTemperature = DEFAULT_TEMP;
    lastHumidity    = NAN;
    dhtValid        = false;
  } else {
    lastTemperature = t;
    lastHumidity    = h;
    dhtValid        = true;

    Serial.print("Temperature: ");
    Serial.print(t);
    Serial.print(" °C, Humidity: ");
    Serial.print(h);
    Serial.println(" %");
  }
}

// ===== GPS measurement =====
void readGPSFix(uint32_t timeoutMs = 10000) { // 10s to keep total cycle short
  Serial.println("Waiting for GPS fix...");
  unsigned long start = millis();
  gpsValid = false;

  while (millis() - start < timeoutMs) {
    while (gpsSerial.available() > 0) {
      char c = gpsSerial.read();
      gps.encode(c);

      if (gps.location.isUpdated()) {
        lastLat = gps.location.lat();
        lastLng = gps.location.lng();
        gpsValid = gps.location.isValid();

        if (gpsValid) {
          Serial.print("Got GPS fix: ");
          Serial.print(lastLat, 6);
          Serial.print(", ");
          Serial.println(lastLng, 6);
          return;
        }
      }
    }
    Blynk.run(); // keep Blynk alive
  }

  // No GPS fix → use fallback coordinates
  Serial.println("No GPS fix, using fallback coordinates.");
  gpsValid = false;
  lastLat  = DEFAULT_LAT;
  lastLng  = DEFAULT_LNG;
}

// ====== Main measurement + Blynk + SMS logic ======
void measureAndSend(bool sendSMS) {
  // 1) Measure heart rate for 10 seconds
  measureHeartRate10sec();

  // 2) Read DHT11 (temperature & humidity)
  readDHTSensor();

  // 3) Get GPS location (lat/long)
  readGPSFix(10000); // 10s

  // 4) Prepare main SMS text (for initial message)
  String smsText;
  smsText = "Health & Location:\n";

  // Heart rate — value used whether measured or fallback
  smsText += "Heart rate: ";
  smsText += String(lastBPM, 1);
  smsText += " bpm\n";

  // Temperature — value used whether measured or fallback
  smsText += "Temp: ";
  smsText += String(lastTemperature, 1);
  smsText += " C, Humidity: ";

  if (!isnan(lastHumidity)) {
    smsText += String(lastHumidity, 1);
    smsText += " %\n";
  } else {
    smsText += "N/A\n";
  }

  // Location — measured GPS or fallback
  smsText += "Location:\nLat: ";
  smsText += String(lastLat, 6);
  smsText += "\nLng: ";
  smsText += String(lastLng, 6);
  smsText += "\n";

  Serial.println("Measurement complete. Data:");
  Serial.println("--------------------");
  Serial.println(smsText);
  Serial.println("--------------------");

  // 5) Send data to Blynk virtual pins
  // V0: Heart rate, V1: Temperature, V2: Latitude, V3: Longitude
  Blynk.virtualWrite(V0, lastBPM);
  Blynk.virtualWrite(V1, lastTemperature);
  Blynk.virtualWrite(V2, lastLat);
  Blynk.virtualWrite(V3, lastLng);

  // 6) Send initial summary SMS only once (first cycle)
  if (sendSMS && !smsSent) {
    Serial.println("Sending initial summary SMS...");
    powerOnModem();

    sim800.begin(115200, SERIAL_8N1, MODEM_RX, MODEM_TX);
    delay(3000);

    sendAT("AT");
    sendAT("ATE0");
    sendAT("AT+CMGF=1");
    sendAT("AT+CSCS=\"GSM\"");
    sendAT("AT+CMEE=2");   // verbose errors

    if (!waitForNetwork(60000)) {
      Serial.println("Failed to register on network, cannot send SMS.");
    } else {
      Serial.println("Network registered, sending summary SMS...");
      sendSMSviaSIM800(PHONE_NUMBER, smsText.c_str());
      smsSent = true;
    }
  }

  // 7) Check abnormal values and send alert SMS (only abnormal values)
  bool abnormal = false;
  String alertText = "ALERT!\n";

  unsigned long now = millis();
  bool canSendAlert = (!alertSmsSent) || (now - lastAlertTime > ALERT_COOLDOWN_MS);

  if (canSendAlert) {

    // Check heart rate only if real reading (not fallback)
    if (bpmValid && (lastBPM > BPM_HIGH_LIMIT || lastBPM < BPM_LOW_LIMIT)) {
      abnormal = true;
      alertText += "Abnormal heart rate: ";
      alertText += String(lastBPM, 1);
      alertText += " bpm\n";
    }

    // Check temperature only if real reading (not fallback)
    if (dhtValid && (lastTemperature > TEMP_HIGH_LIMIT || lastTemperature < TEMP_LOW_LIMIT)) {
      abnormal = true;
      alertText += "Abnormal temperature: ";
      alertText += String(lastTemperature, 1);
      alertText += " C\n";
    }

    if (abnormal) {
      Serial.println("Sending ALERT SMS:");
      Serial.println(alertText);

      powerOnModem();
      sim800.begin(115200, SERIAL_8N1, MODEM_RX, MODEM_TX);
      delay(3000);

      sendAT("AT");
      sendAT("ATE0");
      sendAT("AT+CMGF=1");
      sendAT("AT+CSCS=\"GSM\"");
      sendAT("AT+CMEE=2");

      if (waitForNetwork(60000)) {
        sendSMSviaSIM800(PHONE_NUMBER, alertText.c_str());
        alertSmsSent  = true;
        lastAlertTime = now;
      } else {
        Serial.println("Network error, alert SMS not sent.");
      }
    }
  }
}

// timer callback for 30s updates
void timerCallback() {
  // Repeated measurement & Blynk update (no summary SMS here)
  measureAndSend(false);
}

void setup() {
  Serial.begin(115200);
  delay(1000);

  Serial.println("=== Pulse + DHT11 + GPS + Blynk + SMS + Buzzer ===");

  // Pulse sensor setup
  pinMode(PULSE_PIN, INPUT);
  analogReadResolution(12);                 // 0–4095
  analogSetPinAttenuation(PULSE_PIN, ADC_11db);

  // DHT11 setup
  dht.begin();

  // GPS serial setup
  gpsSerial.begin(9600, SERIAL_8N1, GPS_RX_PIN, GPS_TX_PIN);

  // Buzzer setup
  pinMode(BUZZER_PIN, OUTPUT);
  digitalWrite(BUZZER_PIN, LOW);  // buzzer OFF initially

  // Connect to WiFi + Blynk
  Serial.println("Connecting to WiFi & Blynk...");
  Blynk.begin(BLYNK_AUTH_TOKEN, WIFI_SSID, WIFI_PASS);
  Serial.println("Connected to Blynk.");

  // Initial prompt
  Serial.println("Place your finger gently on the pulse sensor.");
  Serial.println("Keep your hand still and relaxed.");

  for (int i = 5; i > 0; i--) {
    Serial.print("Starting first measurement in ");
    Serial.print(i);
    Serial.println(" seconds...");
    delay(1000);
    Blynk.run();
  }

  // First measurement + summary SMS
  measureAndSend(true);

  // Set timer: repeat measurement & Blynk update every 30 seconds (no summary SMS)
  timer.setInterval(30000L, timerCallback);

  Serial.println("Setup complete. Periodic updates to Blynk every 30s.");
}

void loop() {
  Blynk.run();
  timer.run();
}
